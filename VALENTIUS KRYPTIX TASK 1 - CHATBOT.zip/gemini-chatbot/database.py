
import sqlite3
from datetime import datetime

DATABASE_NAME = "chatbot.db"


# Connect to database
def get_connection():
    connection = sqlite3.connect(DATABASE_NAME)
    connection.row_factory = sqlite3.Row
    return connection


# Create database tables
def initialize_database():

    connection = get_connection()
    cursor = connection.cursor()

    # Conversations table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS conversations (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    """)

    # Messages table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            conversation_id TEXT NOT NULL,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY (conversation_id)
                REFERENCES conversations(id)
                ON DELETE CASCADE
        )
    """)

    connection.commit()
    connection.close()


# Create a new conversation
def create_conversation(conversation_id):

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        INSERT INTO conversations (id, title, created_at)
        VALUES (?, ?, ?)
    """, (
        conversation_id,
        "New Chat",
        datetime.now().isoformat()
    ))

    connection.commit()
    connection.close()


# Save a message
def save_message(conversation_id, role, content):

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        INSERT INTO messages (
            conversation_id, role, content, created_at
        )
        VALUES (?, ?, ?, ?)
    """, (
        conversation_id,
        role,
        content,
        datetime.now().isoformat()
    ))

    connection.commit()
    connection.close()


# Update conversation title
def update_title(conversation_id, title):

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        UPDATE conversations
        SET title = ?
        WHERE id = ?
    """, (title, conversation_id))

    connection.commit()
    connection.close()


# Get all conversations
def get_all_conversations():

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT * FROM conversations
        ORDER BY created_at DESC
    """)

    conversations = [dict(row) for row in cursor.fetchall()]

    connection.close()

    return conversations


# Get messages from a conversation
def get_messages(conversation_id):

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT role, content, created_at
        FROM messages
        WHERE conversation_id = ?
        ORDER BY id ASC
    """, (conversation_id,))

    messages = [dict(row) for row in cursor.fetchall()]

    connection.close()

    return messages


# Delete a conversation
def delete_conversation(conversation_id):

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("PRAGMA foreign_keys = ON")

    cursor.execute("""
        DELETE FROM conversations
        WHERE id = ?
    """, (conversation_id,))

    connection.commit()
    connection.close()
