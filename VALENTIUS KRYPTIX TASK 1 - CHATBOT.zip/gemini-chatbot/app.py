
import os
import time

from flask import Flask, request, jsonify, render_template
from google import genai
from dotenv import load_dotenv

import database as db


# ==========================================
# 1. INITIALIZATION
# ==========================================

load_dotenv()

app = Flask(__name__)

api_key = os.getenv("GEMINI_API_KEY")

if not api_key:
    raise ValueError("Gemini API key not found! Check your .env file.")

client = genai.Client(api_key=api_key)

MODEL_NAME = "gemini-3.5-flash"

MAX_HISTORY = 10
MAX_INPUT_TOKENS = 8000

# Initialize SQLite database
db.initialize_database()


# ==========================================
# 2. SYSTEM PROMPT
# ==========================================

SYSTEM_PROMPT = """
You are a helpful AI chatbot.

Your responsibilities:
- Give clear, friendly and informative answers.
- Maintain context throughout the conversation.
- Remember information shared in earlier messages.
- Provide accurate and easy-to-understand explanations.
- Ask clarifying questions when necessary.
"""


# ==========================================
# 3. TOKEN-BASED CONTEXT MANAGEMENT
# ==========================================

def prepare_context(history, user_entry):

    recent_history = history + [user_entry]

    while len(recent_history) > 1:

        token_response = client.models.count_tokens(
            model=MODEL_NAME,
            contents=recent_history
        )

        total_tokens = token_response.total_tokens

        print("Current input tokens:", total_tokens)

        if total_tokens <= MAX_INPUT_TOKENS:
            break

        # Remove oldest user and assistant message pair
        if len(recent_history) >= 3:
            recent_history = recent_history[2:]
        else:
            break

    return recent_history


# ==========================================
# 4. HOME ROUTE
# ==========================================

@app.route("/")
def home():

    return render_template("index.html")


# ==========================================
# 5. CREATE NEW CONVERSATION
# ==========================================

@app.route("/new-chat", methods=["POST"])
def create_conversation():

    conversation_id = "chat-" + str(time.time_ns())

    db.create_conversation(conversation_id)

    return jsonify({
        "conversation_id": conversation_id
    })


# ==========================================
# 6. GET ALL CONVERSATIONS
# ==========================================

@app.route("/conversations", methods=["GET"])
def get_conversations():

    conversations = db.get_all_conversations()

    result = []

    for chat in conversations:

        result.append({
            "id": chat["id"],
            "title": chat["title"]
        })

    return jsonify(result)


# ==========================================
# 7. GET SELECTED CONVERSATION
# ==========================================

@app.route("/conversations/<conversation_id>", methods=["GET"])
def get_conversation(conversation_id):

    conversations = db.get_all_conversations()

    conversation_exists = any(
        chat["id"] == conversation_id
        for chat in conversations
    )

    if not conversation_exists:

        return jsonify({
            "error": "Conversation not found."
        }), 404

    messages = db.get_messages(conversation_id)

    formatted_messages = []

    for message in messages:

        formatted_messages.append({
            "role": message["role"],
            "parts": [
                {"text": message["content"]}
            ]
        })

    return jsonify({
        "id": conversation_id,
        "messages": formatted_messages
    })


# ==========================================
# 8. DELETE CONVERSATION
# ==========================================

@app.route("/conversations/<conversation_id>", methods=["DELETE"])
def delete_chat(conversation_id):

    conversations = db.get_all_conversations()

    conversation_exists = any(
        chat["id"] == conversation_id
        for chat in conversations
    )

    if not conversation_exists:

        return jsonify({
            "error": "Conversation not found."
        }), 404

    db.delete_conversation(conversation_id)

    return jsonify({
        "message": "Conversation deleted successfully."
    })


# ==========================================
# 9. CHAT API
# ==========================================

@app.route("/chat", methods=["POST"])
def chat():

    try:

        data = request.get_json(silent=True) or {}

        user_message = data.get("message", "")
        conversation_id = data.get("conversation_id", "")

        # Validate message
        if not isinstance(user_message, str) or not user_message.strip():

            return jsonify({
                "error": "Message cannot be empty."
            }), 400

        # Validate conversation ID
        if not isinstance(conversation_id, str) or not conversation_id:

            return jsonify({
                "error": "Invalid conversation ID."
            }), 400

        user_message = user_message.strip()

        # Check conversation existence
        conversations = db.get_all_conversations()

        conversation_exists = any(
            chat["id"] == conversation_id
            for chat in conversations
        )

        if not conversation_exists:

            return jsonify({
                "error": "Conversation not found. Please start a new chat."
            }), 404

        # Retrieve previous messages
        saved_messages = db.get_messages(conversation_id)

        history = []

        for message in saved_messages:

            history.append({
                "role": message["role"],
                "parts": [
                    {"text": message["content"]}
                ]
            })

        # Prepare current user message
        user_entry = {
            "role": "user",
            "parts": [
                {"text": user_message}
            ]
        }

        # Set conversation title using first message
        if len(saved_messages) == 0:

            db.update_title(
                conversation_id,
                user_message[:35]
            )

        # Prepare context
        recent_history = prepare_context(
            history[-MAX_HISTORY * 2:],
            user_entry
        )

        # ======================================
        # GEMINI API WITH RETRY HANDLING
        # ======================================

        for attempt in range(3):

            try:

                response = client.models.generate_content(
                    model=MODEL_NAME,
                    contents=recent_history,
                    config={
                        "system_instruction": SYSTEM_PROMPT
                    }
                )

                break

            except Exception as e:

                error_message = str(e).upper()

                # Do not retry quota errors
                if "429" in error_message or "RESOURCE_EXHAUSTED" in error_message:
                    raise

                # Retry temporary server errors
                elif "503" in error_message or "UNAVAILABLE" in error_message:

                    if attempt == 2:
                        raise

                    wait_time = 2 ** (attempt + 1)

                    print(
                        f"Gemini temporarily unavailable. "
                        f"Retrying in {wait_time} seconds..."
                    )

                    time.sleep(wait_time)

                else:
                    raise

        # Get Gemini response
        bot_reply = response.text

        if not bot_reply:

            raise ValueError("Gemini returned an empty response.")

        # Save user message in SQLite
        db.save_message(
            conversation_id,
            "user",
            user_message
        )

        # Save Gemini response in SQLite
        db.save_message(
            conversation_id,
            "model",
            bot_reply
        )

        return jsonify({
            "reply": bot_reply,
            "conversation_id": conversation_id
        })

    except Exception as e:

        error_message = str(e)

        print("Chatbot Error:", error_message)

        # Handle quota errors
        if "429" in error_message or "RESOURCE_EXHAUSTED" in error_message:

            return jsonify({
                "error": "Gemini API quota exceeded. Please try again after your quota resets or check your API usage limits."
            }), 429

        # Handle temporary server errors
        if "503" in error_message or "UNAVAILABLE" in error_message:

            return jsonify({
                "error": "Gemini is temporarily experiencing high demand. Please try again shortly."
            }), 503

        return jsonify({
            "error": "Sorry, something went wrong. Please try again."
        }), 500


# ==========================================
# 10. RUN FLASK APPLICATION
# ==========================================

if __name__ == "__main__":

    app.run(debug=True)
