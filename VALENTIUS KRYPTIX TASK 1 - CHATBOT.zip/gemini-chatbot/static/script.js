
let conversationId = null;

// Start application
document.addEventListener("DOMContentLoaded", async function () {
    await createNewChat();
    await loadChatHistory();
});


// Create a new conversation
async function createNewChat() {

    try {
        const response = await fetch("/new-chat", {
            method: "POST"
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || "Could not create chat");
        }

        conversationId = data.conversation_id;

        displayWelcomeMessage();

        await loadChatHistory();

        document.getElementById("user-input").focus();

    } catch (error) {
        console.error("New Chat Error:", error);
        alert(error.message);
    }
}


// New Chat button
async function newChat() {
    await createNewChat();
}


// Display welcome message
function displayWelcomeMessage() {

    const chatBox = document.getElementById("chat-box");

    chatBox.innerHTML = `
        <div class="bot-message">
            Hello! I'm your AI assistant. How can I help you today?
        </div>
    `;
}


// Load recent conversations
async function loadChatHistory() {

    try {

        const response = await fetch("/conversations");

        const chats = await response.json();

        const historyBox = document.getElementById("chat-history");

        historyBox.innerHTML = "";

        chats.forEach(chat => {

            const chatItem = document.createElement("div");

            chatItem.className = "history-item";

            if (chat.id === conversationId) {
                chatItem.classList.add("active");
            }

            // Conversation title
            const title = document.createElement("span");

            title.className = "history-title";
            title.textContent = chat.title;

            // Delete button
            const deleteButton = document.createElement("button");

            deleteButton.className = "delete-chat-btn";
            deleteButton.textContent = "×";
            deleteButton.title = "Delete conversation";

            deleteButton.onclick = function (event) {
                event.stopPropagation();
                deleteChat(chat.id);
            };

            chatItem.appendChild(title);
            chatItem.appendChild(deleteButton);

            // Open selected conversation
            chatItem.onclick = function () {
                openChat(chat.id);
            };

            historyBox.appendChild(chatItem);

        });

    } catch (error) {
        console.error("History Error:", error);
    }
}


// Open an existing conversation
async function openChat(id) {

    try {

        const response = await fetch(
            `/conversations/${encodeURIComponent(id)}`
        );

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || "Could not open chat");
        }

        conversationId = data.id;

        const chatBox = document.getElementById("chat-box");

        chatBox.innerHTML = "";

        if (data.messages.length === 0) {
            displayWelcomeMessage();
        } else {

            data.messages.forEach(message => {

                const messageDiv = document.createElement("div");

                if (message.role === "user") {
                    messageDiv.className = "user-message";
                } else {
                    messageDiv.className = "bot-message";
                }

                messageDiv.textContent = message.parts[0].text;

                chatBox.appendChild(messageDiv);

            });

        }

        await loadChatHistory();

        chatBox.scrollTop = chatBox.scrollHeight;

    } catch (error) {
        console.error("Open Chat Error:", error);
        alert(error.message);
    }
}


// Delete a conversation
async function deleteChat(id) {

    const confirmDelete = confirm(
        "Are you sure you want to delete this conversation?"
    );

    if (!confirmDelete) {
        return;
    }

    try {

        const response = await fetch(
            `/conversations/${encodeURIComponent(id)}`,
            {
                method: "DELETE"
            }
        );

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || "Could not delete chat");
        }

        if (conversationId === id) {

            conversationId = null;

            await createNewChat();

        } else {

            await loadChatHistory();

        }

    } catch (error) {
        console.error("Delete Chat Error:", error);
        alert(error.message);
    }
}


// Send message to Gemini
async function sendMessage() {

    const input = document.getElementById("user-input");

    const chatBox = document.getElementById("chat-box");

    const button = document.querySelector(".input-area button");

    const message = input.value.trim();

    if (message === "") {
        return;
    }

    if (!conversationId) {
        await createNewChat();
    }

    // Display user message
    const userDiv = document.createElement("div");

    userDiv.className = "user-message";
    userDiv.textContent = message;

    chatBox.appendChild(userDiv);

    input.value = "";

    button.disabled = true;

    // Loading message
    const loadingDiv = document.createElement("div");

    loadingDiv.className = "bot-message";
    loadingDiv.textContent = "Gemini is thinking...";

    chatBox.appendChild(loadingDiv);

    chatBox.scrollTop = chatBox.scrollHeight;

    try {

        const response = await fetch("/chat", {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({
                message: message,
                conversation_id: conversationId
            })

        });

        const data = await response.json();

        loadingDiv.remove();

        if (!response.ok) {
            throw new Error(data.error || "Something went wrong");
        }

        // Display Gemini response
        const botDiv = document.createElement("div");

        botDiv.className = "bot-message";
        botDiv.textContent = data.reply;

        chatBox.appendChild(botDiv);

        // Refresh sidebar
        await loadChatHistory();

    } catch (error) {

        loadingDiv.textContent = "Error: " + error.message;

    } finally {

        button.disabled = false;

        input.focus();

        chatBox.scrollTop = chatBox.scrollHeight;

    }
}


// Send message when Enter is pressed
document.getElementById("user-input").addEventListener(
    "keydown",
    function (event) {

        if (event.key === "Enter") {
            sendMessage();
        }

    }
);
